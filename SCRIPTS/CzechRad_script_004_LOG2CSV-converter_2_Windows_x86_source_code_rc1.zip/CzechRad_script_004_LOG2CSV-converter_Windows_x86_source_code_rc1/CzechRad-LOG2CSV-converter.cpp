#define FMT_HEADER_ONLY
#include <fmt/format.h>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <vector>
#include <string>
#include <ctime>
#include <sstream>
#include <algorithm>
#include <cmath>

namespace fs = std::filesystem;

// Function to convert DMS (degrees, minutes) to decimal degrees
double dms_to_decimal(const std::string& dms, char direction) {
    if (dms.empty()) return 0.0;
    try {
        // For latitude: 2 digits for degrees (e.g., "50" in "5003.6792")
        // For longitude: 3 digits for degrees (e.g., "014" in "01427.0795")
        size_t degree_len = (dms.size() >= 5 && dms[2] == '.') ? 2 : 3;
        double degrees = std::stod(dms.substr(0, degree_len));
        double minutes = std::stod(dms.substr(degree_len));
        double decimal = degrees + (minutes / 60.0);
        return (direction == 'S' || direction == 'W') ? -decimal : decimal;
    } catch (...) {
        return 0.0;
    }
}

// Function to split a string by delimiter
std::vector<std::string> split(const std::string& str, char delimiter) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(str);
    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

int main() {
    // Check if input and output directories exist
    if (!fs::exists("input")) {
        std::cerr << "Input directory does not exist." << std::endl;
        std::cout << "Press Enter to close this window..." << std::endl;
        std::cin.get();
        return 1;
    }
    if (!fs::exists("output")) {
        fs::create_directory("output");
    }

    // Process each *.LOG file in input directory and subdirectories
    bool all_processed = true;
    std::vector<fs::path> log_files;
    
    // Collect all *.LOG files recursively
    for (const auto& entry : fs::recursive_directory_iterator("input")) {
        if (entry.is_regular_file() && entry.path().extension() == ".LOG") {
            log_files.push_back(entry.path());
        }
    }

    for (const auto& log_path : log_files) {
        std::string filename = log_path.filename().string();
        std::cout << "Processing file: " << log_path.string() << std::endl;

        // Create CSV file with same name in output directory
        fs::path csv_path = fs::path("output") / filename;
        csv_path.replace_extension(".csv");
        std::ofstream csv(csv_path);
        if (!csv.is_open()) {
            std::cerr << "Failed to create CSV file: " << csv_path.string() << std::endl;
            all_processed = false;
            continue;
        }

        // Write CSV header
        csv << "device,device_type,device_ID,date,time_UTC,CPM,ADER_microSvh,latitude,longitude,altitude,pulses5s,pulses_total,GPS_validity,Sat,HDOP\n";

        // Read LOG file
        std::ifstream file(log_path);
        if (!file.is_open()) {
            std::cerr << "Failed to open file: " << log_path.string() << std::endl;
            all_processed = false;
            continue;
        }

        std::string line;
        while (std::getline(file, line)) {
            if (line.empty() || line[0] != '$') continue;

            std::string data = line.substr(1); // Remove '$'
            auto fields = split(data, ',');

            if (fields.size() < 15) continue; // Ensure enough fields

            // Task 1: Load static fields
            std::string device = (fields[0].substr(0, 2) == "BN") ? "Safecast" : (fields[0].substr(0, 2) == "CZ") ? "CzechRad" : "Unknown";
            std::string device_type = fields[0];
            std::string device_id = fields[1];
            std::string date, time_utc;
            size_t t_pos = fields[2].find('T');
            if (t_pos != std::string::npos) {
                date = fields[2].substr(0, t_pos);
                time_utc = fields[2].substr(t_pos + 1);
                time_utc = time_utc.substr(0, time_utc.find('Z'));
            }
            int cpm = 0;
            try { cpm = std::stoi(fields[3]); } catch (...) {}
            int pulses5s = 0;
            try { pulses5s = std::stoi(fields[4]); } catch (...) {}
            int pulses_total = 0;
            try { pulses_total = std::stoi(fields[5]); } catch (...) {}
            std::string gps_validity = fields[6];
            double altitude = 0.0;
            try { altitude = std::stod(fields[11]); } catch (...) {}
            int sat = 0;
            try { sat = std::stoi(fields[13]); } catch (...) {}
            int hdop = 0;
            try { hdop = std::stoi(fields[14]); } catch (...) {}

            // Task 2: Calculate variables
            double ader_microSvh = 0.0;
            if (fields[0].substr(0, 2) == "BN") {
                ader_microSvh = pulses5s * 0.0029940119760479;
            } else if (fields[0].substr(0, 2) == "CZ") {
                ader_microSvh = pulses5s * 0.0030441400304414;
            }
            double latitude = dms_to_decimal(fields[7], fields[8][0]);
            double longitude = dms_to_decimal(fields[9], fields[10][0]);

            // Write to CSV
            csv << fmt::format("{},{},{},{},{},{},{:.4f},{:.6f},{:.6f},{:.2f},{},{},{},{},{}\n",
                device, device_type, device_id, date, time_utc, cpm, ader_microSvh,
                latitude, longitude, altitude, pulses5s, pulses_total, gps_validity, sat, hdop);
        }
        file.close();
        csv.close();

        // Move LOG file to output
        fs::path dest = fs::path("output") / filename;
        try {
            fs::rename(log_path, dest);
        } catch (const fs::filesystem_error& e) {
            std::cerr << "Failed to move file " << log_path.string() << ": " << e.what() << std::endl;
            all_processed = false;
        }
    }

    // Clear input directory
    try {
        for (const auto& entry : fs::recursive_directory_iterator("input")) {
            if (entry.is_regular_file()) {
                fs::remove(entry.path());
            }
        }
    } catch (const fs::filesystem_error& e) {
        std::cerr << "Failed to clear input directory: " << e.what() << std::endl;
        all_processed = false;
    }

    // Report completion
    if (all_processed) {
        std::cout << "Job finished successfully. All *.LOG files processed, converted to CSV, and moved to output directory." << std::endl;
    } else {
        std::cerr << "Warning: Some files could not be processed or moved." << std::endl;
    }

    // Prompt user to press Enter
    std::cout << "Press Enter to close this window..." << std::endl;
    std::cin.get();

    return 0;
}

// Created with Grok AI, released under MIT No Attribution License
// Copyright 2025 Jan Helebrant, czechrad@suro.cz, www.suro.cz
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
// documentation files (the “Software”), to deal in the Software without restriction, including without limitation
// the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
// and to permit persons to whom the Software is furnished to do so.
// THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.