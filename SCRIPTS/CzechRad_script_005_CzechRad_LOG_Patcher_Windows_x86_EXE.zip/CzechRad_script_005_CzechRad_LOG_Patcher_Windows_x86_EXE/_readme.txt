Script 05 - Czechrad LOG Patcher for Windows

This application scans "input" directory for *.LOG files and converts every LOG file to a "legacy" LOG file supported by the SAFECAST API. It also corrects some bugs if you have older firmware - incorrect negative GPS coordinates etc.

The application will:

- Create a backup folder with timestamped backup of all *.LOG files

- Process *.LOG and *.log files recursively in the "input" folder

- Replace "CZRA1" with "CZRDD" and remove incorrectly used minus signs in GPS coordinates

- Recalculate checksums for data lines

- Move processed files to "output" folder

- Clear the "input" folder

- Prompt user to press Enter to exit


Usage:

just put your LOG files in "input" folder and run the EXE.


Application platform:
Windows x86_64, tested on Windows 10 and 11, admin rights are not needed

license:

Created with Grok AI, released under MIT No Attribution License
Copyright 2025 Jan Helebrant, czechrad@suro.cz, www.suro.cz

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
