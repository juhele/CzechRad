#!/bin/bash

# Check if required commands are installed
for cmd in find mv bc date; do
    if ! command -v $cmd &> /dev/null; then
        echo "$cmd is not installed. Please install it."
        exit 1
    fi
done

# Check if input and output directories exist
if [ ! -d "input" ]; then
    echo "Input directory does not exist."
    exit 1
fi
if [ ! -d "output" ]; then
    mkdir output
fi

# Create CSV file with timestamp
timestamp=$(date +%Y-%m-%d_%H-%M)
csvfile="output/${timestamp}_CzechRad_stats.csv"

# Write CSV header
echo "file,device_type,device_ID,date,start_time_UTC,points,duration,ADER_max" > "$csvfile"

# Function to convert seconds to HH:MM:SS
seconds_to_hhmmss() {
    local total_seconds=$1
    local hours=$((total_seconds / 3600))
    local minutes=$(( (total_seconds % 3600) / 60 ))
    local seconds=$((total_seconds % 60))
    printf "%02d:%02d:%02d" $hours $minutes $seconds
}

# Process each *.LOG file
find input -type f -name "*.LOG" | while read -r file; do
    filename=$(basename "$file")
    echo "Processing file: $filename"
    
    # Initialize variables
    device_type=""
    device_id=""
    date=""
    start_time_utc=""
    points=0
    max_ader=0
    
    # Read file line by line
    first_data_line=true
    while IFS= read -r line; do
        if [[ $line == \$* ]]; then
            ((points++))
            
            # Split line into fields
            IFS=',' read -r -a fields <<< "${line#\$}"
            
            # Process first data line
            if $first_data_line; then
                device_type="${fields[0]}"
                device_id="${fields[1]}"
                # Extract date (before T)
                date="${fields[2]%%T*}"
                # Extract time (between T and Z)
                start_time_utc="${fields[2]#*T}"
                start_time_utc="${start_time_utc%Z}"
                first_data_line=false
            fi
            
            # Get 5th column (ADER value, integer)
            if [ -n "${fields[4]}" ]; then
                ader=${fields[4]}
                # Compare with max_ader (integer comparison)
                if [ -z "$max_ader" ] || [ "$ader" -gt "$max_ader" ]; then
                    max_ader=$ader
                fi
            fi
        fi
    done < "$file"
    
    # Calculate ADER_max (multiply max_ader by conversion factor)
    ader_max_formatted=0
    if [ -n "$max_ader" ]; then
    ader_max=$(echo "$max_ader * 0.0365296803652968" | bc -l)
    # Format to #.#### format
    ader_max_formatted=$(LC_NUMERIC=C printf "%0.4f" $ader_max)
    fi
    
    # Calculate duration (points * 5 seconds)
    duration_seconds=$((points * 5))
    duration=$(seconds_to_hhmmss $duration_seconds)
    
    # Write to CSV
    echo "$filename,$device_type,$device_id,$date,$start_time_utc,$points,$duration,$ader_max_formatted" >> "$csvfile"
    
    # Move processed file to output
    mv "$file" "output/$filename"
done

# Verify input directory is empty
if [ -z "$(find input -type f)" ]; then
    echo "Job finished successfully. All *.LOG files processed and moved to output directory."
else
    echo "Warning: Input directory is not empty after processing."
    exit 1
fi

# Created with Grok AI, released under MIT No Attribution License
# Copyright 2025 Jan Helebrant, czechrad@suro.cz, www.suro.cz
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
#
# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
