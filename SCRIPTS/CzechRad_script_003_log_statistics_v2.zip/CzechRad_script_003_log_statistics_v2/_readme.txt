Use:

This script scans "input" directory for *.LOG files and calculates a summary statistics file in a comma separated CSV file you can easily load in spreadsheet software like Microsoft Excel or LibreOffice Calc. The result looks like:

file,device_type,device_ID,date,start_time_UTC,points,duration,ADER_max
04860412_l.LOG,CZRDD,0486,2025-04-12,09:30:10,2461,03:25:05,0,0000

Platform:
GNU/Linux, Bash (Unix shell)

Make sure to:
Save the script (e.g., as CzechRad_script_003_LOG_statistics.sh).
Make it executable: chmod +x CzechRad_script_003_LOG_statistics.sh (can be made interactively in File manager like Dolphin using context menu)
Run it: ./CzechRad_script_003_LOG_statistics.sh. (or run terminal in the particular folder and drag and drop the *.sh file in it and press enter)

license:

Created with Grok AI, released under MIT No Attribution License
Copyright 2025 Jan Helebrant, czechrad@suro.cz, www.suro.cz

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
