#!/bin/bash

# Define input and output directories
INPUT_DIR="input"
OUTPUT_DIR="output"

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Find files containing "2024" and move them to output directory
find "$INPUT_DIR" -type f -exec grep -l "2024" {} \; | while read -r file; do
    mv "$file" "$OUTPUT_DIR/"
    echo "Moved: $file to $OUTPUT_DIR/"
done

# Check if any files were found/moved
if [ $? -eq 0 ]; then
    echo "Script completed successfully"
else
    echo "No files containing '2024' were found"
fi


# Created with Grok AI, released under MIT No Attribution License
# Copyright 2024 Jan Helebrant, czechrad@suro.cz, www.suro.cz
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
#
# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
