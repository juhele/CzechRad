EXE for Microsoft Windows

Use:

This application scans "input" directory for *.LOG files and converts every LOG file in a comma separated CSV file you can easily load in spreadsheet software like Microsoft Excel or LibreOffice Calc. Detects CzechRad and Safecast file using the device string and calculates the dose rate (ADER) values using appropriate conversion factor.

Input:

Safecast sample:

$BNRDD,2408,2022-03-20T15:30:42Z,34,4,42,A,5003.1563,N,01430.9260,E,242.80,A,4,210*4B
$BNRDD,2408,2022-03-20T15:30:47Z,32,2,44,A,5003.1541,N,01430.9260,E,243.70,A,4,210*46
$BNRDD,2408,2022-03-20T15:30:52Z,31,0,44,A,5003.1506,N,01430.9265,E,244.00,A,4,210*45

CzechRad sample:

$CZRA1,0007,2025-01-25T15:13:18Z,26,3,867,A,5003.2222,N,01430.9257,E,284.32,A,5,826*1a
$CZRA1,0007,2025-01-25T15:13:23Z,25,3,870,A,5003.2241,N,01430.9308,E,290.94,A,5,829*1f
$CZRA1,0007,2025-01-25T15:13:28Z,28,4,874,A,5003.2266,N,01430.9340,E,295.45,A,5,832*10

Output:

Safecast output sample:

device,device_type,device_ID,date,time_UTC,CPM,ADER_microSvh,latitude,longitude,altitude,pulses5s,pulses_total,GPS_validity,Sat,HDOP
Safecast,BNRDD,2408,2022-03-20,15:30:42,34,0.0120,500.052605,14.515433,242.80,4,42,A,4,210
Safecast,BNRDD,2408,2022-03-20,15:30:47,32,0.0060,500.052568,14.515433,243.70,2,44,A,4,210
Safecast,BNRDD,2408,2022-03-20,15:30:52,31,0.0000,500.052510,14.515442,244.00,0,44,A,4,210

CzechRad output sample:

device,device_type,device_ID,date,time_UTC,CPM,ADER_microSvh,latitude,longitude,altitude,pulses5s,pulses_total,GPS_validity,Sat,HDOP
CzechRad,CZRA1,0007,2025-01-25,15:13:18,26,0.0091,500.053703,14.515428,284.32,3,867,A,5,826
CzechRad,CZRA1,0007,2025-01-25,15:13:23,25,0.0091,500.053735,14.515513,290.94,3,870,A,5,829
CzechRad,CZRA1,0007,2025-01-25,15:13:28,28,0.0122,500.053777,14.515567,295.45,4,874,A,5,832


Application platform:
Windows x86_64, tested on Windows 10 and 11, admin rights are not needed

license:

Created with Grok AI, released under MIT No Attribution License
Copyright 2025 Jan Helebrant, czechrad@suro.cz, www.suro.cz

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
