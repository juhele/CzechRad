Use:

The application processes CzechRad/Safecast LOG data from the "input" folder and converts it to a standard GPX file.

This will allow you to use measured data from CzechRad/Safecast for geotagging photos from your camera or smartphone (for example, if you forgot to turn on inserting GPS location into Exif). The application is provided as an EXE for Windows, but also works via WINE on Linux. The GPX can be used in applications like Showfoto (part of the free DigiKam package) or GeoSetter to add GPS position to photos.

Platform:
Windows x86_64, tested on Windows 10 and 11, admin rights are not needed

license:

Created with Grok AI, released under MIT No Attribution License
Copyright 2026 Jan Helebrant, czechrad@suro.cz, www.suro.cz

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
