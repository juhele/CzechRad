#!/bin/bash

# Define input directory
INPUT_DIR="input"

# Check if input directory exists
if [ ! -d "$INPUT_DIR" ]; then
    echo "Error: Directory $INPUT_DIR does not exist"
    exit 1
fi

# Find all *.LOG files in input and process them
find "$INPUT_DIR" -type f -name "*.LOG" | while read -r file; do
    # Check if file has at least 5 lines
    if [ $(wc -l < "$file") -ge 5 ]; then
        # Extract characters 13-22 from the fifth line of the file
        date_str=$(sed -n '5p' "$file" | cut -c 13-22)

        # Validate date format (check for YYYY-MM-DD)
        if [[ "$date_str" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then
            # Extract YYYY-MM for subfolder name
            year_month=$(echo "$date_str" | cut -c 1-7)

            # Create subfolder based on YYYY-MM if it doesn't exist
            subfolder="$INPUT_DIR/$year_month"
            mkdir -p "$subfolder"

            # Move the file to the corresponding subfolder
            mv "$file" "$subfolder/"
            echo "Moved $file to $subfolder/"
        else
            echo "Skipping $file: Invalid date format at characters 13-22 on line 5 ($date_str)"
        fi
    else
        echo "Skipping $file: File has fewer than 5 lines"
    fi
done

# Check if any files were processed
if [ $? -eq 0 ]; then
    echo "Script completed successfully"
else
    echo "No *.LOG files were found or processed"
fi

# Created with Grok AI, released under MIT No Attribution License
# Copyright 2025 Jan Helebrant, czechrad@suro.cz, www.suro.cz
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so.
#
# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
